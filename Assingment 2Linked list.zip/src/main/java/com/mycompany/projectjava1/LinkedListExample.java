package com.mycompany.projectjava1;

/**
 * كلاس يمثل العقدة في القائمة المترابطة البسيطة.
 * SLL = Singly Linked List
 */
class SLLNode {
    String areaName;
    SLLNode next;

    public SLLNode(String areaName) {
        this.areaName = areaName;
        this.next = null;
    }
}

/**
 * كلاس يمثل القائمة المترابطة البسيطة.
 */
class SinglyLinkedList {
    SLLNode head;

    /**
     * دالة لإضافة منطقة جديدة في نهاية القائمة.
     */
    public void append(String areaName) {
        SLLNode newNode = new SLLNode(areaName);
        if (head == null) {
            head = newNode;
            return;
        }
        SLLNode last = head;
        while (last.next != null) {
            last = last.next;
        }
        last.next = newNode;
    }

    /**
     * دالة لحل المطلوب في النقطة 1 من الواجب.
     * لا يمكن حل النقطة 2 لأن هذه القائمة لا تحتوي على مؤشر للخلف (prev).
     */
    public void solvePart1() {
        System.out.println("## Solving Assignment Part 1 (Singly Linked List) ##");
        System.out.println("Reading elements at even indices:\n");

        SLLNode current = head;
        int index = 0;
        while (current != null) {
            if (index % 2 == 0) {
                System.out.println("Even Index [" + index + "]: " + current.areaName);
            }
            current = current.next;
            index++;
        }
        System.out.println("\nNote: Part 2 of the assignment requires a 'prev' pointer, which is not available in a Singly Linked List.");
    }
}

/**
 * كلاس يمثل العقدة في القائمة المزدوجة.
 * يحتوي على مؤشر للعقدة التالية (next) والسابقة (prev).
 */
class DblNode {
    String areaName; // اسم المنطقة
    DblNode prev;    // المؤشر للعقدة السابقة
    DblNode next;    // المؤشر للعقدة التالية

    public DblNode(String areaName) {
        this.areaName = areaName;
        this.prev = null;
        this.next = null;
    }
}

/**
 * كلاس يمثل القائمة المترابطة المزدوجة.
 */
class DoublyLinkedList {
    DblNode head;
    DblNode tail;

    public void append(String areaName) {
        DblNode newNode = new DblNode(areaName);
        if (head == null) {
            head = newNode;
            tail = newNode;
            return;
        }
        tail.next = newNode;
        newNode.prev = tail;
        tail = newNode;
    }
    
    public void solvePart1And2() {
        System.out.println("## Solving Assignment Parts 1 & 2 (Doubly Linked List) ##");
        System.out.println("Reading elements at even indices, followed by the element before them:\n");

        DblNode current = head;
        int index = 0;
        while (current != null) {
            if (index % 2 == 0) {
                System.out.println("Even Index [" + index + "]: " + current.areaName);
                if (current.prev != null) {
                    System.out.println("  -> Preceded by: " + current.prev.areaName + "\n");
                } else {
                    System.out.println("  -> This is the first element.\n");
                }
            }
            current = current.next;
            index++;
        }
    }
}

/**
 * كلاس يمثل العقدة في القائمة الدائرية.
 */
class CirNode {
    String areaName;
    CirNode next;

    public CirNode(String areaName) {
        this.areaName = areaName;
        this.next = null;
    }
}

/**
 * كلاس يمثل القائمة المترابطة الدائرية.
 */
class CircularLinkedList {
    CirNode head;

    public void append(String areaName) {
        CirNode newNode = new CirNode(areaName);
        if (head == null) {
            head = newNode;
            head.next = head;
            return;
        }
        CirNode current = head;
        while (current.next != head) {
            current = current.next;
        }
        current.next = newNode;
        newNode.next = head;
    }

    public void solvePart3(int steps) {
        System.out.println("## Solving Assignment Part 3 (Circular Linked List) ##");
        System.out.println("Reading all data and starting from the beginning again (traversing " + steps + " steps):");

        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        CirNode current = head;
        for (int i = 0; i < steps; i++) {
            System.out.println("Step " + (i + 1) + ": " + current.areaName);
            current = current.next;
        }
    }
}

/**
 * الملف الرئيسي للتنفيذ
 */
public class LinkedListExample {
    public static void main(String[] args) {
        // --- البيانات المستخدمة ---
        String[] gazaAreas = {"Gaza City", "Jabalia", "Al-Rimal", "Deir al-Balah", "Khan Younis", "Rafah"};

        // --- الجزء الأول: القائمة البسيطة ---
        SinglyLinkedList gazaSllList = new SinglyLinkedList();
        for (String area : gazaAreas) {
            gazaSllList.append(area);
        }
        gazaSllList.solvePart1();

        System.out.println("\n===================================================\n");

        // --- الجزء الثاني: القائمة المزدوجة ---
        DoublyLinkedList gazaDblList = new DoublyLinkedList();
        for (String area : gazaAreas) {
            gazaDblList.append(area);
        }
        gazaDblList.solvePart1And2();

        System.out.println("\n===================================================\n");

        // --- الجزء الثالث: القائمة الدائرية ---
        CircularLinkedList gazaCirList = new CircularLinkedList();
        for (String area : gazaAreas) {
            gazaCirList.append(area);
        }
        // سوف نتنقل 10 خطوات لإثبات أن القائمة دائرية
        gazaCirList.solvePart3(10);
    }
}