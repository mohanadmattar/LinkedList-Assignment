package com.mycompany.projectjava1;

public class Projectjava1 {

    static void print(int[] a, int size) {
        System.out.print("[");
        for (int i = 0; i < size; i++) {
            System.out.print(a[i]);
            if (i < size - 1) System.out.print(", ");
        }
        System.out.println("]");
    }

    static int deleteAt(int[] a, int size, int index) {
        if (index < 0 || index >= size) return size;
        for (int i = index; i < size - 1; i++) {
            a[i] = a[i + 1];
        }
        return size - 1;
    }

    public static void main(String[] args) {
        int[] a = new int[10];
        int size = 9;
        int[] init = {6,7,8,3,9,2,1,4,5};
        for (int i = 0; i < size; i++) a[i] = init[i];

        System.out.print("Initial array: ");
        print(a, size);

        size = deleteAt(a, size, 3);
        System.out.print("After delete@3: ");
        print(a, size);
    }
}
